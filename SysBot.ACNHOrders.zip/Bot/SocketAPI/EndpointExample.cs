// [SocketAPIController]
public class ExampleEndpoint
{
	// [SocketAPIEndpoint]
	public static object? exampleEP(string test)
	{
		return null;
	}
}