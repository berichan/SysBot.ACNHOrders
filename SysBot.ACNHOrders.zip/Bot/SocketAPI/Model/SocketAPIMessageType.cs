namespace SocketAPI
{
	public enum SocketAPIMessageType
	{
		Response,
		Event,
		Invalid,
	}
}