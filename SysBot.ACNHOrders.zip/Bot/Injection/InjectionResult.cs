﻿namespace SysBot.ACNHOrders
{
    public enum InjectionResult
    {
        Skipped,
        Success,
        FailValidate,
        FailConnectionError,
        Same,
    }
}
