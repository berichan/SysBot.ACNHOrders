﻿namespace SysBot.ACNHOrders
{
    public enum OrderResult
    {
        Success,
        NoArrival,
        NoLeave,
        Faulted
    }
}
